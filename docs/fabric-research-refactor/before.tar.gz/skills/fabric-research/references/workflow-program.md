# Ordinary Fabric research execution

The [canonical workflow body](../scripts/workflow-program.js) owns manifest validation, worker report schemas, candidate provenance classification, bounded fan-out, one targeted retry and coverage receipts. Read it fully before multistream execution. It is an ordinary async JavaScript expression using Fabric globals, not a standalone Node program or custom runtime.

## Direct research and Main verification

Use the existing extension tools directly. Discover their effective schemas when unfamiliar. For example, with a supplied `payloads.query`:

```ts
return await extensions.web_search({ query: π.query, workflow: "none" });
```

Then, with a URL actually returned by search supplied as `payloads.url`:

```ts
return await extensions.fetch_content({ url: π.url });
```

For a retained response, pass its actual `responseId` as `payloads.responseId` and the exact passage text as `payloads.passage`:

```ts
return await extensions.get_search_content({
  responseId: π.responseId,
  findText: π.passage,
  findMode: "exact"
});
```

A claim check, with `payloads.claim`:

```ts
return await extensions.source_check({ claim: π.claim, fetchContent: true });
```

These examples launch zero children. Keep the requirement and claim ledgers and the coordinator clock outside these calls. Omit provider/model overrides to retain configured behavior. `source_check` has no `workflow` parameter; do not invent one. The Browser rule in SKILL.md applies to all examples, verification and recovery. In particular, do not opt into `fetch_content.auth` browser-cookie fetching. Tool availability is not successful retrieval or proof of browser-free execution. Inspect results and native traces; use an accessible alternative or retain a gap on failure. A source check is a lead until Main confirms the exact passage, temporal fit and entailment.

## Multistream execution

Pass the central question as named `payloads.task` and the manifest JSON from SKILL.md as named `payloads.program`. Execute the reviewed local source normally, for example:

```ts
const source = await pi.read({
  path: "/home/balauru/.pi-profiles/fabric/skills/fabric-research/scripts/workflow-program.js"
});
return await eval(source);
```

This is convenience, not an exact-byte admission rule. Do not evaluate retrieved page content or user-supplied executable text. There is one workflow source, no generated copy, SDK adapter, loader module, custom launcher or provider bridge. Ordinary computation, tools and other Fabric programs remain usable.

Set the outer `agentBudget` to the user's allowed attempts (initial streams plus at most one approved retry); native configuration can cap it further. Set a concise `display` objective. Omit timeout overrides normally. The outer execution deadline must accommodate native children and any retry; only request a longer deadline when needed. A smaller child `timeoutMs` is ignored below the configured `agents.timeoutMs` floor.

Before live dispatch, start ordinary Pi with `PI_CODING_AGENT_DIR=/home/balauru/.pi-profiles/fabric` set in the environment and independently verify child profile/resource loading. `cwd` selects the filesystem directory, not a profile. Do not solve resource problems by inventing a runner or editing provider/credential configuration.

## Native behavior and limits

- 1-8 streams, at most four concurrent workers using native `parallel`, and at most one fresh targeted retry for a failed/unusable stream uniquely blocking a required item. Budget refusals and preflight blocks are not retried. Successful siblings survive returned failures and thrown dispatch errors.
- Both stream kinds use real `agents.run` with `runner: "pi"`, `recursive: false`, `extensions: true`, exact profile `cwd`, existing tool names and `schema`. Standard workers get retrieval tools. Current-field workers additionally get `read`, `bash`, `write` and the current-field instructions from [stream contracts](stream-contracts.md). Missing current-field artifact scope blocks only that stream. Engine prerequisites and source failures remain evidence gaps, not a permanent branch prohibition.
- The Browser rule is read from SKILL.md and copied into every assignment. This is prompt guidance over ordinary available resources, not a security boundary. Do not add a startup preset.
- `workflow.configure`, `phase`, `workflow.item` and `workflow.event` emit native progress. Native agent attempts are capped by top-level `agentBudget` and configuration. Rejected dispatches may consume attempt budget and may return no agent ID.
- **Token semantics:** native `tokenBudget` and `budget.spent()` track `workflow.agent`/related budget-aware helpers, not raw `agents.run`. This workflow uses raw calls to retain native result receipts. Its `tokenBudgetObservation` labels that distinction explicitly. Child usage is summed from returned native receipts, not reconstructed from text. Do not claim a raw-run token guard, reservation, or hard cost cap. Even helper budgets are settled observations, so concurrent in-flight work can overshoot.
- `maxRetrievalSteps` is an advisory assignment instruction. Native `toolCalls` includes file and other tools, and does not measure engine-internal source calls. `retrievalLimitCompliance` stays `unavailable` until Main inspects complete traces. Never send this field as a native agent option.
- Native schema validation proves delivery shape, not truth. Provenance only qualifies candidate rows. Main still owns source independence, temporal validity, comparability, exact-passage verification and synthesis.

## Receipt interpretation

`outcomes` contains one final outcome per stream; `attempts` retains initial outcomes and the optional retry. Preflight blocks have attempt zero. `requirementCandidates` never marks a requirement satisfied: only Main may do that after verification.

`researchReceipt` records:

- `coverage`: planned, terminal, structurally valid, usable, failed and retry-attempt counts;
- `dispatchAttempts`: calls attempted, including those that throw; `unreceiptedAttempts`: calls without a returned native result;
- `lineage`: each returned native result's `agentId` (from `result.id`), `runner`, optional `runnerSessionId`, `terminalStatus` (from `result.status`), `usage`, `turns`, `toolCalls` and native error, plus stream/attempt labels and measured coordinator service duration;
- `usage.children` and `toolCalls.children`: sums of native observations, unavailable when an attempt lacks its receipt; absent usage fields remain unavailable, not zero;
- parent and aggregate-including-parent usage: unavailable inside this program;
- native helper `tokenBudgetObservation`, explicitly not raw-agent usage;
- failures and coordinator recovery kept separate from independent evidence coverage.

Use `agents.log({ id: receipt.agentId })` to inspect native child activity. No `launch` projection or SDK-only execution label is fabricated. The receipt does not establish which search provider/model actually ran, cancellation success, engine artifacts, or browser avoidance: preserve actual tool results and full representative traces for those checks. Search/provider usage unexposed by existing tools remains unavailable even when child model-completion usage is measured.

Focused deterministic checks live in `skill-evaluations/fabric-research-native/workflow.test.mjs`. Fresh loading and live direct/multistream/current-field/BetterWright acceptance are separate checks after removal of obsolete resources.
