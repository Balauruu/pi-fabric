import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const root = '/home/balauru/.pi-profiles/fabric';
const source = await readFile(`${root}/skills/fabric-research/scripts/workflow-program.js`, 'utf8');
const skill = await readFile(`${root}/skills/fabric-research/SKILL.md`, 'utf8');
const executionDoc = await readFile(`${root}/skills/fabric-research/references/workflow-program.md`, 'utf8');
const webTools = ['web_search', 'fetch_content', 'get_search_content', 'source_check'];
const requirement = id => ({ id, text: `Resolve ${id}`, required: true, evidenceStandard: 'Primary source and exact passage' });
const stream = (id, kind = 'standard') => ({ id, label: id, kind, requirementIds: [id === 'a' ? 'r1' : 'r2'], requiredSourceClasses: ['primary'], maxRetrievalSteps: 8, contract: 'Resolve the assigned uncertainty, including counterevidence.' });
const manifest = () => ({ routeReason: 'Independent uncertainties', requestedAsOfUTC: null, temporalMode: 'current', requirements: [requirement('r1'), requirement('r2')], coordinatorRequirementIds: [], streams: [stream('a'), stream('b')], webTools, concurrency: 2, allowTargetedRetry: false });
const row = (id = 'r1') => ({ requirementIds: [id], claim: 'Claim', finding: 'Exact finding', url: 'https://example.org/source', status: 'documented fact', confidence: 'high', provenance: { sourceType: 'primary', locator: 'Section 1', retrievedAtUTC: '2026-09-01T00:00:00Z', method: 'Read official record', origin: 'Original publisher', temporalStatus: 'current-only' } });
const report = id => ({ artifacts: [], conclusion: 'Bounded conclusion', evidence: [row(id)], contradictions: [], gaps: [], stopReason: 'requirements-covered' });
const native = (id, value) => ({ id, runner: 'pi', status: 'completed', text: JSON.stringify(value), value, usage: { input: 10, output: 5, cacheRead: 2, cacheWrite: 0, cost: 0.01 }, turns: 2, toolCalls: 3, runnerSessionId: `session-${id}` });
async function run(program = manifest(), options = {}) {
  const calls = [], events = [], phases = [], fanouts = [];
  const context = { π: { program: JSON.stringify(program), task: 'Central decision' },
    pi: { read: async ({ path }) => readFile(path, 'utf8') },
    tools: { list: async () => (options.available ?? webTools).map(name => ({ name })) },
    agents: { run: async request => { calls.push(request); return options.worker ? options.worker(request, calls.length) : native(`native-${calls.length}`, report(request.name.startsWith('a ') ? 'r1' : 'r2')); } },
    workflow: { configure: async x => x, item: async x => { events.push(x); return x; }, event: async x => { events.push(x); } },
    phase: async (...x) => { phases.push(x); },
    parallel: async (thunks, opts) => { fanouts.push(opts); const result = []; let cursor = 0; await Promise.all(Array.from({ length: Math.min(opts.concurrency, thunks.length) }, async () => { while (cursor < thunks.length) { const i = cursor++; result[i] = await thunks[i](); } })); return result; },
    budget: { total: 100, spent: () => 0, remaining: () => 100 },
  };
  const code = options.entrypoint ? `(async () => { ${options.entrypoint} })()` : source;
  const result = await vm.runInNewContext(code, context);
  return { result: JSON.parse(JSON.stringify(result)), calls, events, phases, fanouts };
}

test('native dispatch, authoritative browser assignment, clocks and receipt fields', async () => {
  const m = manifest(); m.runStartedAtUTC = '2026-09-01T10:11:12.000Z';
  const { result, calls, fanouts, phases } = await run(m);
  assert.equal(result.status, 'success'); assert.equal(calls.length, 2);
  const rule = skill.split('## Browser rule\n\n')[1].split('\n## ')[0].trim();
  for (const c of calls) {
    assert.equal(c.runner, 'pi'); assert.equal(c.recursive, false); assert.equal(c.extensions, true); assert.equal(c.cwd, root);
    assert.deepEqual(Array.from(c.tools), webTools);
    assert.ok(c.task.includes(rule)); assert.ok(c.task.includes(m.runStartedAtUTC));
    assert.ok(c.task.includes('Resolve r')); assert.ok(c.task.includes('Primary source and exact passage'));
    for (const key of ['maxRetrievalSteps', 'model', 'timeoutMs']) assert.ok(!(key in c));
  }
  assert.equal(fanouts[0].concurrency, 2); assert.ok(phases.length >= 3);
  const receipt = result.researchReceipt.lineage[0];
  assert.equal(receipt.agentId, 'native-1'); assert.equal(receipt.runner, 'pi'); assert.equal(receipt.runnerSessionId, 'session-native-1'); assert.ok(!('launch' in receipt));
  assert.equal(result.researchReceipt.usage.children.input, 20);
});

test('failed worker preserves successful sibling and native terminal receipt', async () => {
  const { result } = await run(manifest(), { worker: (r, n) => n === 1 ? native('ok', report('r1')) : { ...native('bad', null), status: 'failed', error: 'upstream retrieval tool failed' } });
  assert.equal(result.status, 'partial'); assert.equal(result.outcomes[0].status, 'completed-usable'); assert.equal(result.outcomes[1].status, 'failed-tool');
  assert.equal(result.researchReceipt.lineage.length, 2); assert.equal(result.researchReceipt.lineage[1].terminalStatus, 'failed');
});

test('one fresh targeted retry, not a rerun of successful siblings', async () => {
  const m = manifest(); m.allowTargetedRetry = true;
  const { result, calls } = await run(m, { worker: (r, n) => n === 2 ? { ...native('bad', null), status: 'timed_out', error: 'timeout' } : native(`ok-${n}`, report(n === 1 ? 'r1' : 'r2')) });
  assert.equal(calls.length, 3); assert.equal(calls[2].name, 'b a2'); assert.match(calls[2].task, /Previous attempt/);
  assert.equal(result.status, 'success'); assert.equal(result.attempts.length, 3); assert.equal(result.researchReceipt.coverage.retryAttempts, 1);
});

test('current-field dispatches native engine worker with scoped artifacts and can retry', async () => {
  const m = manifest(); m.streams[1].kind = 'current-field'; m.artifactDir = `${root}/skill-evaluations/fabric-research-native/test-run`; m.allowTargetedRetry = true;
  const { result, calls } = await run(m, { worker: (r, n) => n === 2 ? { ...native('engine-failure', null), status: 'failed', error: 'engine unavailable' } : native(`ok-${n}`, report(n === 1 ? 'r1' : 'r2')) });
  assert.equal(calls.length, 3); assert.equal(result.outcomes[1].kind, 'current-field');
  for (const [i, c] of calls.entries()) if (i > 0) {
    for (const t of ['read', 'bash', 'write', ...webTools]) assert.ok(c.tools.includes(t));
    for (const fragment of ['--no-browser-cookies', 'LAST30DAYS_TRUSTPILOT_NO_BROWSER=1', 'LAST30DAYS_CONFIG_DIR', '--emit=json --json-profile=agent', 'skills/last30days/.venv/bin/python', `b-a${i}`]) assert.ok(c.task.includes(fragment), fragment);
    assert.ok(c.schema.properties.artifacts); assert.ok(c.task.includes('Xiaohongshu'));
  }
});

test('preflight and malformed manifests launch no workers', async () => {
  const { result, calls } = await run(manifest(), { available: [] });
  assert.equal(calls.length, 0); assert.equal(result.outcomes[0].status, 'blocked-preflight');
  const bad = manifest(); bad.streams[1].requirementIds = ['r1'];
  await assert.rejects(run(bad), /Unowned requirements/);
  const date = manifest(); date.requestedAsOfUTC = '2026-02-30'; await assert.rejects(run(date), /requestedAsOfUTC/);
  const empty = manifest(); empty.webTools = []; assert.equal((await run(empty)).calls.length, 0);
});

test('missing current-field artifact directory blocks only that stream', async () => {
  const m = manifest(); m.streams[1].kind = 'current-field';
  const { result, calls } = await run(m); assert.equal(calls.length, 1); assert.equal(result.status, 'partial'); assert.equal(result.outcomes[1].status, 'blocked-preflight'); assert.equal(result.outcomes[1].attempt, 0);
  m.artifactDir = `${root}/skill-evaluations/fabric-research-native/../escape`; assert.equal((await run(m)).calls.length, 1);
});

test('missing or foreign provenance is retained but cannot satisfy requirements', async () => {
  const { result } = await run(manifest(), { worker: (r, n) => {
    const value = report(n === 1 ? 'r1' : 'r2'); if (n === 1) delete value.evidence[0].provenance.locator; else value.evidence[0].requirementIds = ['r1']; return native(`p-${n}`, value);
  } });
  assert.equal(result.researchReceipt.coverage.usable, 0); assert.equal(result.researchReceipt.coverage.structurallyValid, 2); assert.equal(result.outcomes[1].unassignedEvidenceRows, 1); assert.ok(result.outcomes[0].report.evidence.length);
});

test('native budget refusal survives; token observation is not raw-run enforcement', async () => {
  const { result } = await run(manifest(), { worker: (r, n) => { if (n === 2) throw new Error('Fabric agent budget exhausted (1 per execution)'); return native('allowed', report('r1')); } });
  assert.equal(result.status, 'partial'); assert.equal(result.outcomes[1].status, 'failed-budget'); assert.equal(result.researchReceipt.lineage.length, 1);
  assert.equal(result.researchReceipt.dispatchAttempts, 2); assert.equal(result.researchReceipt.unreceiptedAttempts, 1);
  assert.equal(result.researchReceipt.tokenBudgetObservation.appliesToRawAgentsRun, false); assert.equal(result.researchReceipt.tokenBudgetObservation.spent, 0);
  assert.equal(result.researchReceipt.capabilities.hardPerAgentRetrievalLimit, false);
  assert.equal(result.researchReceipt.lineage[0].retrievalLimitCompliance, 'unavailable');
});

test('concurrency stays bounded and only truly sole owners can retry', async () => {
  const m = manifest(); m.concurrency = 99; m.allowTargetedRetry = true; m.streams[0].requirementIds = ['r1', 'r2'];
  const { calls, fanouts } = await run(m, { worker: () => native('empty', { ...report('r1'), evidence: [] }) });
  assert.equal(fanouts[0].concurrency, 2); assert.equal(calls.length, 3); // r1 has one owner, r2 has two
  m.coordinatorRequirementIds = ['r1']; assert.equal((await run(m, { worker: () => native('empty', { ...report('r1'), evidence: [] }) })).calls.length, 2);
  const mixed = await run(m, { worker: (r, n) => native(`owner-${n}`, n === 1 ? report('r1') : { ...report('r2'), evidence: [] }) });
  assert.equal(mixed.calls.length, 2); // usable a also owns missing r2; b is not its sole owner
});

test('missing native telemetry remains unavailable, not zero-filled', async () => {
  const { result } = await run(manifest(), { worker: (r, n) => { const v = native(`missing-${n}`, report(n === 1 ? 'r1' : 'r2')); delete v.usage; delete v.toolCalls; return v; } });
  assert.equal(result.researchReceipt.lineage[0].usage, 'unavailable');
  assert.equal(result.researchReceipt.usage.children.input, 'unavailable'); assert.equal(result.researchReceipt.toolCalls.children, 'unavailable');
});

test('native schema failure is retained without inventing validator paths or a retry', async () => {
  const { result, calls } = await run(manifest(), { worker: (r, n) => n === 1 ? native('valid', report('r1')) : { ...native('invalid', null), status: 'failed', error: 'Structured agent output failed schema validation' } });
  assert.equal(calls.length, 2); assert.equal(result.status, 'partial'); assert.equal(result.outcomes[1].status, 'failed-schema');
  assert.equal(result.outcomes[1].diagnostic.jsonPath, 'unavailable'); assert.equal(result.researchReceipt.lineage[1].agentId, 'invalid');
});

test('ordinary documented execution pattern runs the canonical source', async () => {
  const blocks = Array.from(executionDoc.matchAll(/```ts\n([\s\S]*?)```/g), m => m[1]);
  const { result, calls } = await run(manifest(), { entrypoint: blocks.at(-1) });
  assert.equal(result.status, 'success'); assert.equal(calls.length, 2);
});

test('documented direct retrieval uses configured tools and zero children', async () => {
  const blocks = Array.from(executionDoc.matchAll(/```ts\n([\s\S]*?)```/g), m => m[1]).slice(0, 4);
  const calls = []; let children = 0;
  const extensions = Object.fromEntries(webTools.map(name => [name, async args => { calls.push({ name, args }); return { text: 'source evidence', isError: false }; }]));
  for (const body of blocks) await vm.runInNewContext(`(async () => { ${body} })()`, { extensions, π: { query: 'topic', url: 'https://example.org/source', responseId: 'actual-response', passage: 'Exact passage', claim: 'Claim' }, agents: { run: () => { children++; throw new Error('No direct children'); } } });
  assert.equal(children, 0); assert.deepEqual(calls.map(c => c.name), webTools.slice(0, 2).concat(['get_search_content', 'source_check']));
  assert.equal(calls[0].args.workflow, 'none'); assert.equal(calls[2].args.responseId, 'actual-response');
  for (const { args } of calls) { assert.ok(!('provider' in args)); assert.ok(!('model' in args)); assert.ok(!('auth' in args)); }
});
