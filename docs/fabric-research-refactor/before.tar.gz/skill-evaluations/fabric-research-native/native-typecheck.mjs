// Read-only probe of the installed Fabric compiler, not an executor or worker adapter.
import { readFile } from 'node:fs/promises';
import { typeCheckFabricCode } from '../../npm/node_modules/pi-fabric/dist/runtime/type-checker.js';
import { guestTypeDeclarations } from '../../npm/node_modules/pi-fabric/dist/runtime/guest-types.js';
const source = await readFile(new URL('../../skills/fabric-research/scripts/workflow-program.js', import.meta.url), 'utf8');
const result = typeCheckFabricCode(`return await ${source}`, guestTypeDeclarations(true));
console.log(JSON.stringify({source:'skills/fabric-research/scripts/workflow-program.js', compiler:'installed Fabric typeCheckFabricCode with native guestTypeDeclarations(true)', mocked:false, errors:result.errors}, null, 2));
process.exitCode = result.errors.length ? 1 : 0;
